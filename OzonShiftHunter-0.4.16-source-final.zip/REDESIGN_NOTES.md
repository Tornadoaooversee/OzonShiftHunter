# Ozon Shift Hunter — UI refresh

The Android UI in `app/src/main/java/ru/pythonlab/ozonshifthunter/MainActivity.kt` has been refreshed.

## Visual changes
- Dark navy palette with blue accent, soft borders and rounded cards.
- Clear numbered sections and improved visual hierarchy.
- Search settings grouped into a dedicated card.
- Day/night shift choices displayed as compact rows.
- Weekday rules separated with dividers and horizontal choices.
- Automation controls and safety guidance grouped together.
- Dedicated system status panel and a more readable diagnostic log.
- Larger primary save action and quieter secondary actions.

## Behavior
Existing preference keys, booking policy values, accessibility-service navigation,
notification permission request, log actions, and save validation are retained.

## Build
Build with Android Gradle Plugin 8.7.3 / Kotlin 2.0.21:
`./gradlew :app:assembleDebug`

The APK was not built in this environment because the Gradle distribution could not
be downloaded (network DNS unavailable). Please build in Android Studio or a machine
with Gradle distribution access.
