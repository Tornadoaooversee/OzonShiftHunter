# Static analysis: Ozon Job 2.36.0-GMS-release

Date of analysis: 2026-11-14
Source: user-provided `ru.ozon.hire-204_arm64-v8a (1).xapk`

## Package metadata (from XAPK metadata and base APK manifest)

- Application label: Ozon Job
- Package ID: `ru.ozon.hire`
- Version name: `2.36.0-GMS-release`
- Version code: `204`
- minSdk: `26`
- targetSdk: `36`
- compileSdk: `36`
- ABI split: `arm64-v8a`
- XAPK contains `base.apk`, ARM64 native split, Russian locale split, and `xxhdpi` density split.
- XAPK ZIP integrity test completed without errors.

## Manifest observations

- Declares `POST_NOTIFICATIONS`, `RECEIVE_BOOT_COMPLETED`, `WAKE_LOCK`, network state/internet, location, camera, and several feature-specific permissions.
- Declares location foreground services including `ru.ozon.hire.miniappadapters.location.entrypoints.service.LocationTrackerService` and `ru.ozon.fresh.courier.geoservice.GeolocationService`.
- Declares AndroidX WorkManager `SystemJobService` and `SystemForegroundService`.
- Declares FCM and RuStore push integration components.
- The manifest does not declare an AccessibilityService for Ozon Job itself.

These declarations show that Ozon Job uses notification, location, and scheduled-work infrastructure. They do **not** prove that shift availability is polled in the background or that a shift-opening push notification is emitted.

## Booking-related DEX symbols observed

The DEX string/class inventory includes booking and shift-related components such as:

- `BookingViewModel`, `BookingRepositoryImpl`, `BookingInteractor`
- `BookShiftViewModel`, `BookShiftBottomSheet`, `BookShiftContent`
- `DayShiftsViewModel`, `DayShiftsBottomSheet`
- `ConflictShift`, `GetShiftConflictsCalendarUseCase`
- `QueueLegendBottomSheet`, `NavQueueLegendBottomSheet`
- `PostBookingFlowCoordinatorImpl`
- `ProbabilityType`
- Events including `OnBookShiftsClicked`, `OnShiftSignUpClicked`, `OnBookingShiftSuccess`, and `OnShiftConfirmed`

This is static symbol evidence only. It is not a verified description of the server protocol, runtime flow, or user-visible strings.

## Implications for Ozon Shift Hunter

1. Use the exact observed package ID `ru.ozon.hire` rather than a broad `contains("ozon")` filter. Implemented in Shift Hunter 0.4.10.
2. Keep the AccessibilityService event-driven and foreground-only. The existence of WorkManager/location services inside Ozon Job does not grant Shift Hunter access to Ozon Job's hidden UI or internal work queues.
3. A NotificationListenerService could observe only notifications Ozon Job actually posts, after the user explicitly enables Notification Access. It cannot guarantee shift discovery or perform UI booking while Ozon Job is backgrounded.
4. Screen-off and device-powered-off behavior must remain distinct: Android can deliver notifications while the screen is off, but a fully powered-off phone cannot run Shift Hunter or receive new app events.
5. Do not rely on private endpoints, reverse-engineered authenticated APIs, or attempts to bypass Ozon controls. No network protocol or backend behavior was analyzed.

## Verification limits

- Static inspection only; no Ozon Job runtime instrumentation was performed.
- APK signing certificate was not verified because `apksigner` was unavailable in the analysis environment.
- Android Gradle build and on-device interaction tests were not run.
- Resource table strings were not decoded, so exact button labels and probability-color mapping remain unverified against this binary.
