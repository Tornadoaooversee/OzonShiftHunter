package ru.pythonlab.ozonshifthunter.core

/** Текстовый дамп дерева для лога: пользователь может прислать его вместо скриншотов. */
object ScreenDump {
    const val MAX_LINES = 220

    fun lines(snap: ScreenSnapshot): List<String> {
        val out = ArrayList<String>()
        for (n in snap.nodes) {
            val interesting = n.text.isNotEmpty() || n.desc.isNotEmpty() || n.viewId.isNotEmpty() || n.clickable || n.isToggleLike
            if (!interesting) continue
            if (out.size >= MAX_LINES) { out += "… усечено, всего узлов ${snap.nodes.size}"; break }
            out += "N${n.index} p=${n.parent} d=${n.depth} path=${n.path.joinToString("/")} ${n.className.substringAfterLast('.')} " +
                "text=\"${n.text}\" desc=\"${n.desc}\" id=${n.viewId} " +
                "clk=${n.clickable} en=${n.enabled} sel=${n.selected} chk=${n.checked} chkable=${n.checkable} " +
                "b=${n.bounds.left},${n.bounds.top},${n.bounds.right},${n.bounds.bottom}"
        }
        return out
    }

    /**
     * Отпечаток структуры экрана без координат. Для проверки перед действием учитывает не только
     * подписи, но и путь/тип/id/кликабельность узлов: одинаковые надписи на разных экранах не должны
     * считаться одним и тем же экраном. SHA-256 исключает короткие hashCode-коллизии.
     */
    fun signature(snap: ScreenSnapshot): String {
        // Feed SHA-256 incrementally instead of constructing one large canonical String.
        // Length-prefixing every string also makes the encoding unambiguous even when labels
        // contain separators or newlines. This path runs for every accessibility snapshot.
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        fun putInt(value: Int) {
            digest.update((value ushr 24).toByte())
            digest.update((value ushr 16).toByte())
            digest.update((value ushr 8).toByte())
            digest.update(value.toByte())
        }
        fun putString(value: String) {
            val bytes = value.toByteArray(Charsets.UTF_8)
            putInt(bytes.size)
            digest.update(bytes)
        }
        fun putBoolean(value: Boolean) = digest.update((if (value) 1 else 0).toByte())

        putString(snap.packageName)
        putInt(snap.nodes.size)
        snap.nodes.forEach { n ->
            putInt(n.path.size)
            n.path.forEach(::putInt)
            putString(n.className)
            putString(n.viewId)
            putString(n.label)
            putBoolean(n.clickable)
            putBoolean(n.enabled)
            putBoolean(n.selected)
            putBoolean(n.checked)
        }
        val bytes = digest.digest()
        val hex = "0123456789abcdef"
        return buildString(bytes.size * 2) {
            bytes.forEach { b ->
                val v = b.toInt() and 0xff
                append(hex[v ushr 4])
                append(hex[v and 0x0f])
            }
        }
    }
}
