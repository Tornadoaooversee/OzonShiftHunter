# Accessibility Service manifest correction

The service declaration must remain `android:exported="true"` so Android can discover and bind the declared AccessibilityService through the system-protected `BIND_ACCESSIBILITY_SERVICE` permission.

The latest region-autocomplete archive had reverted this attribute to `false`; this patch restores `true` from the earlier accessibility-fix archive. The service still requires `android.permission.BIND_ACCESSIBILITY_SERVICE`, and the service itself is not callable by ordinary third-party apps without that signature/system permission.

This is a manifest/source correction only. It is not an APK build or on-device verification. Build and verify on the target Android version before enabling active booking; keep observation mode enabled until the service connects and logs are checked.
